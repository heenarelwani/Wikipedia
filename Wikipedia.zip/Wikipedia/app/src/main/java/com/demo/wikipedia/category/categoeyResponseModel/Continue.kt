package com.demo.wikipedia.category.categoeyResponseModel

import com.google.gson.annotations.SerializedName

class Continue(
    @SerializedName("accontinue") val accontinue:String,
    @SerializedName("continue") val _continue : String
)
